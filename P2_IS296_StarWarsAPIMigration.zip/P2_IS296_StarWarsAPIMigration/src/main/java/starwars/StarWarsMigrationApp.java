package starwars;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import config.StarWarsConfig;
import starwars.dao.StarWarsDAO;
import starwars.vo.Film;
import starwars.vo.People;
import starwars.vo.Planet;
import starwars.vo.Starship;

public class StarWarsMigrationApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new AnnotationConfigApplicationContext(StarWarsConfig.class);
		StarWarsDAO swDAO = (StarWarsDAO) ctx.getBean("getStarWarsDAO");
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("user-agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		RestTemplate restTemplate = new RestTemplate();
		
		for (int i = 1; i < 50; i++) {	
			try {
				ResponseEntity<People> rPeople = restTemplate.exchange("https://swapi.co/api/people/" + i + "/", HttpMethod.GET, entity,
						People.class);
				swDAO.insertPeople(rPeople.getBody());
				
				ResponseEntity<Film> rFilms = restTemplate.exchange("https://swapi.co/api/films/" + i + "/", HttpMethod.GET, entity,
						Film.class);
				swDAO.insertFilm(rFilms.getBody());
				
				ResponseEntity<Planet> rPlanets = restTemplate.exchange("https://swapi.co/api/planets/" + i + "/", HttpMethod.GET, entity,
						Planet.class);
				swDAO.insertPlanets(rPlanets.getBody());
				
				ResponseEntity<Starship> rStarShips = restTemplate.exchange("https://swapi.co/api/starships/" + i + "/", HttpMethod.GET, entity,
						Starship.class);		
				swDAO.insertStarship(rStarShips.getBody());
			} catch(HttpClientErrorException e) {
				System.out.println("Response code is 404");
			}	
		}
		JdbcTemplate jdbcTemplate = ctx.getBean(JdbcTemplate.class);
		JdbcTemplate.execute("SCRIPT 'Downloads/tmp/sw.sql' ");

		
	}
}
