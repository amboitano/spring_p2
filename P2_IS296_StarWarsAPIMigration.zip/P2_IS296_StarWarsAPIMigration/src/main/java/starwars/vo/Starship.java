package starwars.vo;

public class Starship {
	private String name;
	private String model;
	private String manufacturer;
	private double cost_in_credits;
	private String length;
	private int crew;
	private int passengers;
	private double cargo_capacity;
	private String hyperdrive_rating;
	private String starship_class;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public double getCost_in_credits() {
		return cost_in_credits;
	}
	public void setCost_in_credits(double cost_in_credits) {
		this.cost_in_credits = cost_in_credits;
	}
	public String getLength() {
		return length;
	}
	public void setLength(String length) {
		this.length = length;
	}
	public int getCrew() {
		return crew;
	}
	public void setCrew(int crew) {
		this.crew = crew;
	}
	public int getPassengers() {
		return passengers;
	}
	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}
	public double getCargo_capacity() {
		return cargo_capacity;
	}
	public void setCargo_capacity(double cargo_capacity) {
		this.cargo_capacity = cargo_capacity;
	}
	public String getHyperdrive_rating() {
		return hyperdrive_rating;
	}
	public void setHyperdrive_rating(String hyperdrive_rating) {
		this.hyperdrive_rating = hyperdrive_rating;
	}
	public String getStarship_class() {
		return starship_class;
	}
	public void setStarship_class(String starship_class) {
		this.starship_class = starship_class;
	}
	
	
	
	
}
