package starwars.persistence;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import starwars.vo.Film;
import starwars.vo.People;
import starwars.vo.Planet;
import starwars.vo.Result;
import starwars.vo.Starship;

public interface StarWarsMapper {

	@Select("Select * from T_FILM")
	public List<Film> getFilms();
	
	@Insert("Insert into T_FILM values (#{title}, #{episode_id}, #{opening_crawl}, #{director}, #{release_date})") 
	public void insertFilms(Film film);
	
	@Insert("Insert into T_PLANET values (#{name}, #{rotation_period}, #{orbital_period}, #{orbital_period}, #{climate}, "
			+ "#{gravity}, #{terrain}, #{surface_water}, #{population})") 
	public void insertPlanets(Planet planet);
	
	@Insert("Insert into T_PEOPLE values (#{name}, #{height}, #{mass}, #{hair_color}, #{skin_color}, "
			+ "#{birth_year}, #{gender})") 
	public void insertPeople(People people);
	
	@Insert("Insert into T_STARSHIP values ( #{name}, #{model}, #{manufacturer}, #{cost_in_credits}, #{length}, #{crew}, #{passengers}, #{cargo_capacity}, #{hyperdrive_rating}, #{starship_class})")
	public void insertStarship(Starship starship);
	
	
}
