package starwars.dao;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import starwars.persistence.StarWarsMapper;
import starwars.vo.Film;
import starwars.vo.People;
import starwars.vo.Planet;
import starwars.vo.Starship;

public class StarWarsDAO {
	private StarWarsMapper swm;
	
	public StarWarsDAO(StarWarsMapper swm) {
		this.swm = swm;
	}
	
	public List<Film> getFilms() {
		return swm.getFilms();
	}
	
	@Transactional
	public void insertFilm(Film film) {
		swm.insertFilms(film);
	}
	
	@Transactional
	public void insertPlanets(Planet planet) {
		swm.insertPlanets(planet);
	}
	
	@Transactional
	public void insertPeople(People people) {
		swm.insertPeople(people);
	}	
	
	@Transactional
	public void insertStarship(Starship starship) {
		swm.insertStarship(starship);
	}
	
	
	
}
