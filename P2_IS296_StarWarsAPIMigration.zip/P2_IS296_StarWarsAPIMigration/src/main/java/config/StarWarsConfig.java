package config;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import starwars.dao.StarWarsDAO;
import starwars.persistence.StarWarsMapper;

@Configuration
@MapperScan("starwars.persistence")
@EnableTransactionManagement
public class StarWarsConfig {
	
	@Bean SqlSessionFactory sqlSessionFactory() throws Exception {
		SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
		sessionFactory.setTypeAliasesPackage("starwars.vo");
		sessionFactory.setDataSource(dataSource());
		return sessionFactory.getObject();
	}
	
	@Bean
	public DataSourceTransactionManager dataSourceTransactionManager(DataSource ds) {
		DataSourceTransactionManager dataSourceTransactionManager = new DataSourceTransactionManager();
		dataSourceTransactionManager.setDataSource(ds);
		return dataSourceTransactionManager;
	}
	
	@Bean
	public DataSource dataSource() throws SQLException {
		DataSource ds = new EmbeddedDatabaseBuilder().addScript("classpath:schema.sql").build();
		ds.getConnection().setAutoCommit(true);
		return ds;
	}
	
	@Bean
	public StarWarsDAO getStarWarsDAO(StarWarsMapper swm) {
		return new StarWarsDAO(swm);
	}
	
	@Bean JdbcTemplate getJdbcTemplate() throws SQLException {
		return new JdbcTemplate(dataSource());
	}
}
