drop table T_PLANET if exists;
drop table T_STARSHIP if exists;
drop table T_PEOPLE if exists;
drop table T_FILM if exists;

create table T_PLANET (name varchar(100), rotation_period varchar(100), orbital_period varchar(50), diameter decimal(8,2), climate varchar(100), gravity varchar(100), terrain varchar(100), surface_water decimal(8,2), population varchar(100) );
create table T_STARSHIP (name varchar(100), model varchar(100), manufacturer varchar(100), cost_in_credits decimal(15,2), length varchar(100), crew integer, passengers integer, cargo_capacity decimal(15,2), hyperdrive_rating varchar(100), starship_class varchar(100) );
create table T_PEOPLE (name varchar(100), height varchar(100), mass varchar(100), hair_color varchar(100), skin_color varchar(100), birth_year varchar(100), gender varchar(100));
create table T_FILM (title varchar(100), episode_id varchar(100), opening_crawl varchar(1000), director varchar(100), release_date varchar(100));


